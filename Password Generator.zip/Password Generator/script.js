document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('password-options');
    const passwordOutput = document.getElementById('generated-password');
    const copyButton = document.getElementById('copy-button');
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('nav-links');

    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const length = document.getElementById('length').value;
        const includeUppercase = document.getElementById('include-uppercase').checked;
        const includeNumbers = document.getElementById('include-numbers').checked;
        const includeSymbols = document.getElementById('include-symbols').checked;

        const password = generatePassword(length, includeUppercase, includeNumbers, includeSymbols);
        passwordOutput.textContent = password;
    });

    copyButton.addEventListener('click', () => {
        const textarea = document.createElement('textarea');
        textarea.value = passwordOutput.textContent;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Password copied to clipboard');
    });

    function generatePassword(length, includeUppercase, includeNumbers, includeSymbols) {
        const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
        const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numberChars = '0123456789';
        const symbolChars = '!@#$%^&*()_+[]{}|;:,.<>?';
        let allChars = lowercaseChars;

        if (includeUppercase) {
            allChars += uppercaseChars;
        }
        if (includeNumbers) {
            allChars += numberChars;
        }
        if (includeSymbols) {
            allChars += symbolChars;
        }

        let password = '';
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * allChars.length);
            password += allChars[randomIndex];
        }
        return password;
    }
});